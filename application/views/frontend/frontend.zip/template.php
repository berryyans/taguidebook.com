<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="index, follow" />
    <link rel="shortcut icon" href="<?php echo site_url();?>/assets/images/favicon.png">
    <meta name="author" content="info@kejari-buleleng.go.id">
    <meta name="content_type" content="Standard" />
    <title>
        <?php echo $this->template->title->default("Default title"); ?>
    </title>
    <meta name="description" content="<?php echo $this->template->description; ?>">
    <meta name="keywords" content="<?php echo $this->template->keyword; ?>">
    <meta property="fb:app_id" content="161134343906646" />
    <meta property="og:site_name" content="Website Resmi Kejaksaan Negeri Buleleng" />
    <meta property="og:title" content="Website Resmi Kejaksaan Negeri Buleleng" />
    <meta property="og:image" content="<?php echo site_url();?>/assets/images/bg.png" />
    <meta property="og:url" content="http://www.kejari-buleleng.go.id" />
    <meta property="og:description" content="Selamat Datang di Website Resmi Kejaksaan Negeri Buleleng" />
    <meta property="og:type" content="website" />
    <meta property="article:author" content="https://www.facebook.com/kejaribuleleng" />
    <meta property="article:publisher" content="https://www.facebook.com/kejaribuleleng" />
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@kejaribuleleng" />
    <meta name="twitter:creator" content="@kejaribuleleng" />
    <meta name="twitter:title" content="Website Resmi Kejaksaan Negeri Buleleng" />
    <meta name="twitter:description" content="Website Resmi Kejaksaan Negeri Buleleng" />
    <meta name="twitter:url" content="http://www.kejari-buleleng.go.id" />
    <meta name="twitter:image" content="<?php echo site_url();?>/assets/images/bg.png" />
    <!-- Bootstrap core CSS -->
    <link href="<?php echo site_url();?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Site CSS -->
    <link href="<?php echo site_url();?>/assets/css/loading.css" rel="stylesheet">
    <!-- Bootstrap custom CSS -->
    <link href="<?php echo site_url();?>/assets/css/style.min.css" rel="stylesheet" />
    <!-- Font Awesome CSS -->
    <link href="<?php echo site_url();?>/assets/css/font-awesome.css" rel="stylesheet" />
    <!-- custom CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo site_url();?>/assets/css/component.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo site_url();?>/assets/css/slick.css" />
    <link rel="stylesheet" type="text/css" href="<?php echo site_url();?>/assets/css/slick-theme.css" />

    <link rel="stylesheet" href="<?php echo site_url();?>/assets/css/animate.min.css">

    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,300|Open+Sans:400,300,600,700" rel="stylesheet" />
    <link href="<?php echo site_url();?>/assets/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo site_url();?>/assets/css/style.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="<?php echo site_url();?>/assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo site_url();?>/assets/css/owl.theme.default.min.css">

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">

    <!--custom CSS-->

    <style type="text/css">
        body {
            background-image: url(<?php echo site_url();
            ?>/assets/images/bg.jpg);
            background-repeat: no-repeat;
            background-position: 50% 0%;
            line-height: 1.428571429;
            color: #333333;
            background-color: #ffffff;
        }
        
        div.small-tiles {
            padding-left: 10px;
            padding-right: 0px;
        }
        
        div.tiles {
            max-width: 150px;
            height: 110px;
            width: 100%;
            padding-right: 0px;
            padding-left: 0px;
            padding-top: 20px;
        }
        
        .text-small {
            font-size: 12px;
        }
        
        div.group-tiles {
            padding-left: 0px;
            padding-right: 0px;
        }
        
        .content-box img.tiles {
            width: 110px;
            height: 110px;
        }
        
        span.title-tiles {
            font-size: 20px;
            font-weight: bold;
        }
        
        span.title-besar {
            font-size: 30px;
        }
        
        .content-title {
            padding: 10px;
        }
        
        p.font-sambutan {
            font-size: 12px;
        }
        
        .no-border {
            border: none;
        }
        
        span.besar {
            font-size: 22px;
        }
        
        div.overlay-post {
            margin-top: 30px;
            padding-top: 10px;
            padding-bottom: 10px;
            color: #fff;
        }
        
        .border-custom-left {
            border-left: 1px solid #ddd;
        }
        
        .border-custom-right {
            border-right: 1px solid #ddd;
        }
        
        @media (min-width: 1200px) {
            div.navbar-header img {
                /*width: 350px;*/
            }
            .overlay-custom {
                width: 160px;
            }
        }
        
        @media (max-width: 1000px) {
            div.navbar-header img {
                width: 360px;
                display: inline;
            }
        }
        
        @media (max-width: 768px) {
            div.navbar-header img {
                /*width: 260px;*/
                display: inline;
            }
            .overlay-custom {
                width: 100%;
            }
        }
        
        @media (max-width: 425px) {
            div.navbar-header img {
                margin-top: 10px;
                width: 260px;
                display: inline;
            }
            .content-box img.tiles {
                width: 140px;
                height: 140px;
            }
            .tulisankecil {
                font-size: 13px;
            }
        }
        
        @media (max-width: 380px) {
            div.navbar-header img {
                margin-top: 10px;
                width: 260px;
                display: inline;
            }
            .content-box img.tiles {
                width: 110px;
                height: 110px;
            }
            .overlay-custom {
                width: 100%;
            }
        }
        
        @media (max-width: 425px) {
            div.navbar-header img {
                margin-top: 10px;
                width: 260px;
                display: inline;
            }
            .content-box img.tiles {
                width: 140px;
                height: 140px;
            }
            .tulisankecil {
                font-size: 13px;
            }
        }
        
        @media (min-width: 770px) {
            .left-column {
                padding-right: 15px !important;
            }
            .right-column {
                padding-left: 15px !important;
            }
        }
        
        .row {
            margin: unset !important;
        }
        
        @font-face {
            font-family: 'Myriad Pro';
            src: url('<?php echo site_url();?>/assets/fonts/MyriadPro-Cond.otf');
            /*font-weight: normal;*/
            font-style: condensed;
        }
        
        .myriadpro {
            /* font-family: 'Myriad Pro'; */
            font-family: 'Roboto', sans-serif;
            /*font-weight: bold;*/
        }
        
        .header-main.affix.header-transparent {
            background-color: #1B79C3;
            /*min-height: 80px;*/
            /*text-align: -webkit-center;*/
        }
        
        .header-main.header-transparent {
            background-color: #1B79C3;
            border-top: 3px solid #2196f3;
            min-height: 80px;
        }
        
        .header-top.header-primary .navbar-nav>li>a:hover {
            background-color: #002E40;
        }
        
        .header-main.header-transparent .navbar-nav>li>a:hover {
            background-color: #002E40;
        }
        
        img.logo {
            position: absolute;
            z-index: 1001;
            left: 0px;
            top: 0px;
            height: 80px;
        }
        
        .navbar {
            min-height: 40px;
        }
        
        .header-main.affix .navbar-nav>li>a {
            padding-top: 23px;
            padding-bottom: 27px;
        }
        
        header .header-primary {
            background: #1F1F1F;
        }

        .nav_dropdowns > li > a {
            /*padding: 13px 10px;*/
            /*border-right: 1px solid #CBCBCA;*/
            display: block;
        }

        .header-primary a {
            color: #C77B1D;
        }
        
        .header-top {
            z-index: 1000;
            position: unset;
        }
        
        @media (min-width: 768px) {
            .navbar-nav>li>a {
                padding-top: 10px;
                padding-bottom: 10px;
            }
        }
        /* Navbar Shrink CSS*/
        
        .navbar-brand > img {
            /*width:100%;
            height:66px;
            max-width: 305px;
            margin-top:-20px;
            */
            transition: all 0.3s;
        }
        
        div.shrink .navbar-brand > img {
            /*height: 90px;*/
            margin-top: 0px;
            transition: all 0.3s;
        }
        
        img.mbl {
            position: absolute;
            z-index: 1001;
            left: 10px;
            top: 8px;
            height: 60px;
        }
        
        .header-main.header-transparent .dropdown-menu a:not(.btn):hover {
            /*background: #012b4d;*/
            color: #fff;
        }
        /***********************
         * Essential Structure *
         ***********************/
        
        .flexsearch--wrapper {
            height: auto;
            width: auto;
            max-width: 100%;
            overflow: hidden;
            background: transparent;
            margin: 0;
            position: static;
        }
        
        .flexsearch--form {
            overflow: hidden;
            position: relative;
        }
        
        .flexsearch--input-wrapper {
            /*padding: 0 66px 0 0;*/
            padding-left: 20px;
            /* Right padding for submit button width */
            overflow: hidden;
        }
        
        .flexsearch--input {
            width: 100%;
        }
        /***********************
         * Configurable Styles *
         ***********************/
        
        .flexsearch {
            /*padding: 0 25px 0 200px;*/
            /* Padding for other horizontal elements */
        }
        
        .flexsearch--input {
            -webkit-box-sizing: content-box;
            -moz-box-sizing: content-box;
            box-sizing: content-box;
            height: 30px;
            padding: 0 46px 0 17px;
            background-color: #ffffff;
            /* border-color: #1A2C44; */
            border-radius: 26px;
            border-style: solid;
            border-width: 0px;
            margin-top: 5px;
            color: #000000;
            font-family: 'Helvetica', sans-serif;
            font-size: 12px;
            -webkit-appearance: none;
            -moz-appearance: none;
        }
        
        .flexsearch--submit {
            position: absolute;
            right: 0;
            top: 0;
            display: block;
            width: 38px;
            height: 30px;
            padding: 0;
            border: none;
            margin-top: 8px;
            margin-right: 0px;
            background: transparent;
            color: #888;
            font-family: 'Helvetica', sans-serif;
            font-size: 20px;
            line-height: 30x;
        }
        
        .flexsearch--input:focus {
            outline: none;
            border-color: #333;
        }
        
        .flexsearch--input:focus.flexsearch--submit {
            color: #fff;
        }
        
        .flexsearch--submit:hover {
            color: #000000;
            cursor: pointer;
        }
        
        ::-webkit-input-placeholder {
            color: #888;
        }
        
        input:-moz-placeholder {
            color: #888;
        }
        /****************
         * Pretify demo *
         ****************/
        
        .h1 {
            float: left;
            margin: 25px;
            color: #333;
            font-family: 'Helvetica', sans-serif;
            font-size: 45px;
            font-weight: bold;
            line-height: 45px;
            text-align: center;
        }
        
        .dropdowns nav_dropdowns,
        .dropdowns ul,
        .dropdowns li,
        .dropdowns a {
            margin: 0;
            padding: 0;
        }
        
        .dropdowns a {
            text-decoration: none;
        }
        
        .toggleMenu {
            display: none;
        }
        
        .nav_dropdowns {
            list-style: none;
            *zoom: 1;
        }
        
        .nav_dropdowns:before,
        .nav_dropdowns:after {
            content: " ";
            display: table;
        }
        
        .nav_dropdowns:after {
            clear: both;
        }
        
        .nav_dropdowns ul {
            list-style: none;
        }
        
        .nav_dropdowns a {
            padding: 15px 15px;
        }
        
        .nav_dropdowns a:hover {
            background: #17ace4;
            color: #ffffff;
        }
        
        .nav_dropdowns li {
            position: relative;
        }
        
        .nav_dropdowns > li {
            float: left;
        }
        
        .nav_dropdowns > li > .parent {
            background-image: url("<?php echo site_url();?>/assets/images/downArrow.png");
            background-repeat: no-repeat;
            background-position: 98% 50%;
        }
        
        .nav_dropdowns > li > a {
            display: block;

        }
        
        .nav_dropdowns li ul {
            position: absolute;
            left: -9999px;
        }
        
        .nav_dropdowns > li.hover > ul {
            left: 0;
        }
        
        .nav_dropdowns li li.hover ul {
            left: 100%;
            top: 0;
        }
        
        .nav_dropdowns li li a {
            display: block;
            position: relative;
            z-index: 100;
            color: #ffffff;
        }
        
        .nav_dropdowns li li li a {
            z-index: 200;
            color: #ffffff;
        }
        /* fonts */
        
        .dropdowns {
            font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
        }
        /* colors */
        /* togle menu button for narrow screens */
        
        .toggleMenu {
            background: none;
            color: #ffffff;
        }
        /* general navigation background color */
        
        .nav_dropdowns {
            background: none;
        }
        /* general navigation link font color */
        
        .nav_dropdowns a {
            color: #ffffff;
            font-weight: bold;
        }
        /* first level items borders */
        
        .nav_dropdowns > li {
            /*border-top: 1px solid #104336;*/
        }
        /* second level navigation colors */
        
        .nav_dropdowns li li a {
            background: #2196f3;
            border-top: 1px solid #2196F3;
        }
        
        .nav_dropdowns li li li a {
            background: #2196f3;
            border-top: 1px solid #2196F3;
        }
        /* layout */
        
        .dropdowns {
            width: 100%;
            max-width: 1700px;
            margin: 15px auto;
        }
        
        a.toggleMenu {
            padding: 10px 15px;
        }
        
        .nav_dropdowns ul {
            width: 15em;
        }
        
        .nav_dropdowns > li > .parent {}
        
        @media screen and (max-width: 768px) {
            .active {
                display: block;
            }
            .nav_dropdowns > li {
                float: none;
            }
            .nav_dropdowns > li > .parent {
                background-position: 95% 50%;
            }
            .nav_dropdowns li li .parent {
                background-image: url("<?php echo site_url();?>/assets/images/downArrow.png");
                background-repeat: no-repeat;
                background-position: 95% 50%;
            }
            .nav_dropdowns ul {
                display: block;
                width: 100%;
            }
            .nav_dropdowns > li.hover > ul,
            .nav_dropdowns li li.hover ul {
                position: static;
            }
        }
        
        [data-slide="prev"] {
            margin-right: 10px;
        }
        
        .carousel-fade .carousel-inner .item {
            opacity: 0;
            transition-property: opacity;
        }
        
        .carousel-fade .carousel-inner .active {
            opacity: 1;
        }
        
        .carousel-fade .carousel-inner .active.left,
        .carousel-fade .carousel-inner .active.right {
            left: 0;
            opacity: 0;
            z-index: 1;
        }
        
        .carousel-fade .carousel-inner .next.left,
        .carousel-fade .carousel-inner .prev.right {
            opacity: 1;
        }
        
        .carousel-fade .carousel-control {
            z-index: 2;
        }
        
        .nav-tabs.tabs-v3>li.active>a:after {
            display: none;
        }
        
        .small-tiles {
            padding-left: 10px;
            padding-right: 0px;
        }
        
        div.group-tiles {
            padding-left: 0px;
            padding-right: 0px;
        }
        
        .content-box img.tiles {
            width: 110px;
            height: 110px;
        }
        
        span.title-tiles {
            font-size: 20px;
            font-weight: bold;
        }
        
        span.title-besar {
            font-size: 30px;
        }
        
        .content-title {
            padding: 10px;
        }
        
        .text-small {
            text-transform: uppercase;
            font-size: 15px;
            font-family: 'Myriad Pro';
            padding: 8px 5px 0 5px;
            line-height: 100%;
        }
        
        .site-section-top {
            margin-top: 45px;
        }
        
        .banner-atas-default {
            margin-top: 0px;
        }
        
        .running-section {
            min-height: 35px;
        }
        
        .sticky-header-container {
            /*min-height: 80px;*/
        }
        
        .banner-atas-scroll {
        margin-top: 50px;
        }
        
        ul.marquee {
            width: 100% !important;
        }

        #custom_carousel .item {

            color:#FFFFFF;
            background-color:rgba(0,0,0,0.5);
        }
        #custom_carousel .controls{
            overflow-x: auto;
            overflow-y: hidden;
            padding:0;
            margin:0;
            text-align: center;
            position: relative;
            background:#FFFFFF;
        }
        #custom_carousel .controls li {
            display: table-cell;
            width: 1%;
            max-width:70px;
        }
        #custom_carousel .controls li.active {
            background-color:#eee;
            /*border-top:3px solid red;*/
        }
        #custom_carousel .controls a small {
            overflow:hidden;
            display:block;
            font-size:10px;
            margin-top:5px;
            font-weight:bold
        }

        .carousel-caption {
            left: 0;
            right: 0;
            bottom: 0px;
            background: #000;
            background: -moz-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 31%,rgba(0,0,0,.7) 100%);
            background: -webkit-gradient(linear,left top,left bottom,color-stop(0,transparent),color-stop(31%,rgba(0,0,0,.47)),color-stop(100%,rgba(0,0,0,.7)));
            background: -webkit-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 31%,rgba(0,0,0,.7) 100%);
            background: -o-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 31%,rgba(0,0,0,.7) 100%);
            background: -ms-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 31%,rgba(0,0,0,.7) 100%);
            background: linear-gradient(to bottom,transparent 0,rgba(0,0,0,.47) 31%,rgba(0,0,0,.7) 100%);
            text-align:justify;
            margin: 0 15px;
            padding:30px;
        }

        ul.slider li {
            border-left: 1px solid #c7c7c7;
            border-bottom: 1px solid #c7c7c7;
        }

        ul.slider {
            border-right: 1px solid #c7c7c7;
        }

        .slider > li > a:hover, .slider > li > a:focus {
            text-decoration: none;
            background: none;
        }

        .slider > li:hover, .slider > li:focus {
            text-decoration: none;
            background-color: #eeeeee;
        }

        .video-caption {
            position: absolute;
            z-index: 10;
            color: #fff;
            text-shadow: 0 1px 2px rgba(0,0,0,.6);
            /*left: 0;
            right: 0;*/
            bottom: 0;
            background: #000;
            background: -moz-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 100%,rgba(0,0,0,.7) 100%);
            background: -webkit-gradient(linear,left top,left bottom,color-stop(0,transparent),color-stop(100%,rgba(0,0,0,.47)),color-stop(100%,rgba(0,0,0,.7)));
            background: -webkit-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 100%,rgba(0,0,0,.7) 100%);
            background: -o-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 100%,rgba(0,0,0,.7) 100%);
            background: -ms-linear-gradient(top,transparent 0,rgba(0,0,0,.47) 100%,rgba(0,0,0,.7) 100%);
            background: linear-gradient(to bottom,transparent 0,rgba(0,0,0,.47) 100%,rgba(0,0,0,.7) 100%);
            text-align: justify;
            padding: 10px;
        }

        .footer>li>a .footer>p{
            color: #ffffff;
        }

        .footer>p {
		    padding-top: 20px;
		    font-size: 14px;
		    color: #a1a1a1;
		    border-top: solid 5px #15A95D;
		    color: #ffffff;
		}

        .box {
            background: none;
            margin-bottom: 10px;
            position: relative!important
        }
        
        .fokus .title {
            background: #c00;
            padding: 0 15px;
            margin-bottom: 0
        }
        
        .box .title,
        .box2 .title,
        .title_out {
            font-size: 16px;
            background: #2196F3;
            color: #fff;
            text-transform: none;
            padding: 20px 10px 0px 20px;
        }
        
        .fokus .list_berita_1 li.hl .pic,
        .list_berita_1 li .pic,
        .list_berita_1 li.hl .pic {
            background: #000;
            text-align: center;
            position: relative;
            overflow: hidden
        }

        footer h5 {
            text-transform: uppercase;
            color: #434343;
        }
        
        footer a {
            color: #ffffff;
        }
        
        .bg-alt {
            color: #434343;
        }
        
        .footer-copyright .copyright-text {
            font-size: 12px;
            color: #fff;
        }
        
        footer .kecil {
            font-size: 14px;
        }
        
        footer .kecil-judul {
            font-size: 16px;
        }
        
        footer ul.fa-ul li {
            padding-bottom: 6px;
        }
        
        footer img.logo-bawah {
            height: 100px;
        }
        
        .icon-social.icon-social-color.circle li {
            border-radius: 10% !important;
        }
        
        .icon-social.icon-social-color li a {
            width: 26px;
            height: 26px;
            font-size: 17px;
            color: #000;
        }
        
        .icon-social li a:hover {
            color: #fff;
        }
        
        .icon-social.icon-social-color li a>i {
            line-height: 28px;
        }
        
        .instagram {
            background: #fff;
        }
    </style>
    <script src="<?php echo site_url();?>/assets/js/jquery.min.js"></script>
    <script src="<?php echo site_url();?>/assets/js/bootstrap.min.js"></script>
    <script src="<?php echo site_url();?>/assets/js/scripts.min.js"></script>
    <script src="<?php echo site_url();?>/assets/js/modernizr.custom.js"></script>
    <script src="<?php echo site_url();?>/assets/css/script.js"></script>
</head>
<body>
    <div class="preloader">
        <div class="loader"><img src="<?php echo site_url();?>/assets/images/loading.png" alt=""></div>
    </div>
    <?php
    echo $this->template->header;
    ?>
    <?php
    echo $this->template->content;
    echo $this->template->sidebar;
    ?>
    <?php
    echo $this->template->footer;
    ?>
</body>
</html>