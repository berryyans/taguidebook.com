<header>
    <div class="header-top header-primary hidden-xs hidden-sm">
                <div style="background-color: #FFFFFF;">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <div style="margin-top:5px"><i class="fa fa-clock-o" style="color: #000000"></i>
                            <?php
                            $tanggal = date("Y-m-d");
                            $day = date('D', strtotime($tanggal));
                            $dayList = array(
                                'Sun' => 'Minggu',
                                'Mon' => 'Senin',
                                'Tue' => 'Selasa',
                                'Wed' => 'Rabu',
                                'Thu' => 'Kamis',
                                'Fri' => 'Jumat',
                                'Sat' => 'Sabtu'
                            );
                            echo $dayList[$day].", ".format_date_in(2,date("Y-m-d"));
                            ?>
                        </div>
                    </div>
                    <div class="col-md-1" style="padding: 0px;margin:0px;"><span class="btn btn-block" style="width: 100%;height: 100%;background-color: #56a1f2;    border-radius: 0px;color:#ffffff">Treding</span></div>
                    <div class="col-md-5">
                        <div class="container">
                            <div class="row">
                                <div class="col-sm-12" style="background-color: #ffffff">
                                    <!-- get marquee css -->

                                    <link type="text/css" href="<?php echo site_url();?>/assets/css/jquery.marquee.min.css" rel="stylesheet" title="default" media="all">
                                    
                                    <script src="<?php echo site_url();?>/assets/js/jquery.marquee.min.js"></script>
                                    
                                    <script type="text/javascript">
                                    <!--//
                                    var use_debug = false;
                                
                                    function debug(){
                                        if( use_debug && window.console && window.console.log ) console.log(arguments);
                                    }
                                
                                    // on DOM ready
                                    $(document).ready(function (){
                                        $(".marquee").marquee({
                                            loop: -1
                                            // this callback runs when the marquee is initialized
                                            , init: function ($marquee, options){
                                                debug("init", arguments);
                                
                                                // shows how we can change the options at runtime
                                                if( $marquee.is("#marquee2") ) options.yScroll = "bottom";
                                            }
                                            // this callback runs before a marquee is shown
                                            , beforeshow: function ($marquee, $li){
                                                debug("beforeshow", arguments);
                                
                                                // check to see if we have an author in the message (used in #marquee6)
                                                var $author = $li.find(".author");
                                                // move author from the item marquee-author layer and then fade it in
                                                if( $author.length ){
                                                    $("#marquee-author").html("<span style='display:none;'>" + $author.html() + "</span>").find("> span").fadeIn(850);
                                                }
                                            }
                                            // this callback runs when a has fully scrolled into view (from either top or bottom)
                                            , show: function (){
                                                debug("show", arguments);
                                            }
                                            // this callback runs when a after message has being shown
                                            , aftershow: function ($marquee, $li){
                                                debug("aftershow", arguments);
                                
                                                // find the author
                                                var $author = $li.find(".author");
                                                // hide the author
                                                if( $author.length ) $("#marquee-author").find("> span").fadeOut(250);
                                            }
                                        });
                                    });
                                    
                                    var iNewMessageCount = 0;
                                    
                                    function addMessage(selector){
                                        // increase counter
                                        iNewMessageCount++;
                                
                                        // append a new message to the marquee scrolling list
                                        var $ul = $(selector).append("<li>New message #" + iNewMessageCount + "</li>");
                                        // update the marquee
                                        $ul.marquee("update");
                                    }
                                    
                                    function pause(selector){
                                        $(selector).marquee('pause');
                                    }
                                    
                                    function resume(selector){
                                        $(selector).marquee('resume');
                                    }
                                    //-->
                                    </script>
                                    <!-- ul running text -->
                                    <ul id="marquee1" class="marquee" style="margin-top:5px;">
                                            <?php
                                            foreach ($running_text as $running_text)
                                            {
                                            echo '<li style="color:#000000">'.$running_text->text.'</li>';
                                            }
                                            ?>
                                    </ul>
                                    <p style="background:#fff"></p>
                                    <!-- .ul running text -->

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1" style="padding:5px 2px 2px 0px;">
                        <div class="controls pull-right hidden-xs">
                            <a class="left btn btn-sm btn-default" href="#carousel-award" data-slide="prev" style="background: none"><i class="fa fa-chevron-left"></i></a>
                            <a class="right btn btn-sm btn-default" href="#carousel-award" data-slide="next" style="background: none"><i class="fa fa-chevron-right"></i></a>
                        </div>
                    
                    </div> <!-- .col-md-offset-2 col-md-6 -->

                    <div class="col-md-3" style="padding: 0px;">
                        <?php
                        $index_media = 0;
                        foreach ($media as $rmedia){?>
                        <span class="margin-right-5 margin-top-10">
                            <a target="_BLANK" href="<?php echo $rmedia->url ?>" title="<?php echo $rmedia->name ?>">
                            <img src="<?=site_url()."uploads/medias/".$rmedia->img;?>"></i>
                            </a>
                        </span>
                        <?php
                        }
                        ?>
                    </div> <!-- .col-md-4 -->
                </div> <!-- .row -->
            </div> <!-- .container -->
        </div>
    </div> <!-- .header-top -->

    <div class="sticky-header-container">
        <div id="sticky-header" class="header-main header-transparent navbar mega-menu affix" data-spy="affix" data-offset-top="50">
          <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <div class="navbar-header shrink">
                        <!-- logo utama -->
                        <a href="https://subang.go.id/index.php/home" class="navbar-brand hidden-xs hidden-sm">
                            <img class="img-responsive logo" src="<?=site_url();?>assets/images/header_646123.png">
                        </a>
                    </div> <!-- .navbar-header -->
                </div>
                <div class="col-sm-8">
                    <style type="text/css">
                        .dropdowns nav_dropdowns, .dropdowns ul, .dropdowns li, .dropdowns a  {margin: 0; padding: 0;}

                        .dropdowns a {text-decoration: none;}

                        .toggleMenu {
                            display:  none;
                        }
                        .nav_dropdowns {
                            list-style: none;
                             *zoom: 1;
                        }
                        .nav_dropdowns:before,
                        .nav_dropdowns:after {
                            content: " "; 
                            display: table; 
                        }
                        .nav_dropdowns:after {
                            clear: both;
                        }
                        .nav_dropdowns ul {
                            list-style: none;
                        }
                        .nav_dropdowns a {
                            padding: 15px 15px;
                        }

                        .nav_dropdowns a:hover {
                            background: #17ace4;
                        }
                        .nav_dropdowns li {
                            position: relative;
                        }
                        .nav_dropdowns > li {
                            float: left;
                        }
                        .nav_dropdowns > li > .parent {
                            background-image: url("https://subang.go.id/assets/images/downArrow.png");
                            background-repeat: no-repeat;
                            background-position: 98% 50%;
                        }
                        .nav_dropdowns > li > a {
                            display: block;
                        }
                        .nav_dropdowns li  ul {
                            position: absolute;
                            left: -9999px;
                        }
                        .nav_dropdowns > li.hover > ul {
                            left: 0;
                        }
                        .nav_dropdowns li li.hover ul {
                            left: 100%;
                            top: 0;
                        }
                        .nav_dropdowns li li a {
                            display: block;
                            position: relative;
                            z-index:100;
                        }
                        .nav_dropdowns li li li a {
                            z-index:200;
                        }

                        /* fonts */
                        .dropdowns {font-family: "Helvetica Neue", Helvetica, Arial, sans-serif; }

                        /* colors */

                        /* togle menu button for narrow screens */
                        .toggleMenu {
                            background: none;
                            color: #ffffff;
                        }

                        /* general navigation background color */
                        .nav_dropdowns {
                             background:none;
                        }

                        /* general navigation link font color */
                        .nav_dropdowns a {
                            color:#fff;
                        }

                        /* first level items borders */
                        .nav_dropdowns > li {
                            /*border-top: 1px solid #104336;*/
                        }

                        /* second level navigation colors */
                        .nav_dropdowns li li a {
                            background: #2196f3;
                            border-top: 1px solid #2196F3;
                        }
                        
                        .nav_dropdowns li li li a {
                            background: #2196f3;
                            border-top: 1px solid #2196F3;
                        }

                        /* layout */
                        .dropdowns {
                            width: 100%;
                            max-width: 900px;
                            margin: 15px auto;
                        }

                        a.toggleMenu {
                            padding: 10px 15px;
                        }

                        .nav_dropdowns ul {
                            width: 15em;
                        }

                        .nav_dropdowns > li > .parent {
                            
                        }

                        @media screen and (max-width: 768px) {
                            .active {
                                display: block;
                            }
                            .nav_dropdowns > li {
                                float: none;
                            }
                            .nav_dropdowns > li > .parent {
                                background-position: 95% 50%;
                            }
                            .nav_dropdowns li li .parent {
                                background-image: url("https://subang.go.id/assets/images/downArrow.png");
                                background-repeat: no-repeat;
                                background-position: 95% 50%;
                            }
                            .nav_dropdowns ul {
                                display: block;
                                width: 100%;
                            }
                           .nav_dropdowns > li.hover > ul , .nav_dropdowns li li.hover ul {
                                position: static;
                            }

                        }
                    </style>

                    <div class="dropdowns">

                    <!-- <a class="toggleMenu pull-right" href="#">Menu</a> !-->
                    <div class="toggleMenu" style="display: none;">
                        <label for="toggleMenu" id="logo-mobile">
                            <table width="100%" border="0" align="center">
                              <tbody><tr>
                                <td><img src="https://subang.go.id/assets/images/logo_mobile.png" class="img-responsive" style="width:300px;height:50px;"></td>
                                <td>&nbsp;</td>
                                <td><href="#"><i class="fa fa-bars" style="font-size:40px;"></i></href="#"></td>
                              </tr>
                            </tbody></table>
                        </label>
                    </div>

                    <div class="dropdowns">

                        <!-- <a class="toggleMenu pull-right" href="#">Menu</a> !-->
                        <div class="toggleMenu">
                            <label for="toggleMenu" id="logo-mobile">
                                <table width="100%" border="0" align="center">
                                  <tr>
                                    <td><img src="<?php echo site_url();?>/assets/images/logo_mobile.png" class="img-responsive" style="width:300px;height:50px;" /></td>
                                    <td>&nbsp;</td>
                                    <td><href="#"><i class="fa fa-bars" style="font-size:40px;"></i></a></td>
                                  </tr>
                                </table>
                            </label>
                        </div>
                        <?=menunavbar();?>        
                        </div>

                        <script type="text/javascript" src="<?php echo site_url();?>/assets/js/dropdowns.js"></script>
                        <script>
                            $(".dropdowns").dropdowns();
                        </script>
        
                    </div>

                    
                </div> <!-- .navbar-container -->
            </div> <!-- .row -->
          </div> <!-- .container -->
        </div> <!-- .header-main -->
    </div>
</header>