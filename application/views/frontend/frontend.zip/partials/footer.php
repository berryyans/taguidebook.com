<!-- Footer -->
<footer class="footer" style="border-top: none; background: #1F2024;">
    <div class="container">
        <div class="row">
            
            <div class="col-md-12 no-padding">
                

                <div class="col-md-4 margin-bottom-15">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 margin-bottom-20">
                            <h4 class="myriadpro" style="font-weight: bold;">Kontak Informasi</h4>
                            <ul class="fa-ul margin-top-15">
                               <?php
                               foreach ($pengaturan as $pengaturan){?>
                                <li><i class="fa-li fa-md link-default fa fa-phone"></i>
                                  <?=$pengaturan->fax;?>                              
                                </li>
                                <li><i class="fa-li fa-md link-default fa fa-home"></i> 
                                  <h4  style=""><?=$pengaturan->company;?></h4>
                                  <p><?=$pengaturan->address;?></p>
                                </li>
                                <li><i class="fa-li fa-md link-default fa fa-envelope"></i>
                                  <a href="mailto:<?=$pengaturan->email;?>"><?=$pengaturan->email;?></a>
                                </li>
                                <li><i class="fa-li fa-md link-default fa fa-globe"></i>
                                  <?=$pengaturan->website;?>                                
                                </li>
                                <?php
                               }
                               ?>
                            </ul>
                        </div> <!-- .col-md-3 -->
                    </div>
                </div>

                <div class="col-md-4 margin-bottom-15">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 margin-bottom-20">
                            <h4 class="myriadpro margin-bottom-15" style="font-weight: bold;">Follow Us</h4>
                            <br>
                            <?php 
                              echo "<p>User Online : $pengunjungonline</p>
                                    <p>Today Visitor : $pengunjung</p>
                                    <p>Hits hari ini : $hits[total]</p>
                                    <p>Total pengunjung : $totalpengunjung[total]</p>";
                            ?>
                        </div> <!-- .col-md-6 -->
                    </div> <!-- .row -->
                </div> <!-- .col-md-6 -->

                <div class="col-md-4 margin-bottom-15">
                    <div class="col-md-12">
                        <div class="row">
                            <div class="col-md-12 col-sm-12 margin-bottom-20">
                                <h4 class="myriadpro margin-bottom-15" style="font-weight: bold;">Facebook Like Box</h4>
                                <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Ffacebookindonesia&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;show_border=true&amp;header=false" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:100%; height:258px;" allowTransparency="true"></iframe>
                            </div> <!-- .col-md-3 -->
                        </div> <!-- .row -->
                    </div> <!-- .col-md-6 -->
                </div> <!-- .col-md-6 -->

            </div>

        </div> <!-- .row -->
    </div> <!-- .container -->

    <!-- footer-copyright -->
    <div class="footer-copyright" style="margin-top: 0px;background: #16151A; padding: 0px;">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                
                    <p class="copyright-text" align="center">
                      <?=$pengaturan->copyright;?>
                    </p>

                </div> <!-- .col-md-12 -->

            </div> <!-- .row -->
        </div> <!-- .container -->
    </div> <!-- .footer-copyright -->


</footer>
<!-- /.Footer -->

</div><!-- /.container -->
<script type="text/javascript">
    $(window).scroll(function() {
      if ($(document).scrollTop() > 40) {
        $('.navbar-header').addClass('shrink');
      } else {
        $('.navbar-header').removeClass('shrink');
      }
      // if ($(document).scrollTop() >= 200) {
      //   $("nav.navbar-fixed-top").autoHidingNavbar();
      // }
    });
</script>
<script src="<?php echo site_url();?>/assets/js/slick.min.js"></script>
<style type="text/css">

        .custom-prev,.custom-next {
            position: absolute;
            z-index: 1000;
            top: 45%;
        }
        
        .custom-prev {
            left: -15px;
        }

        .custom-next {
            right: -15px;
        }
    </style>

<script>
$(document).ready(function(){
$('.carousel-galeri-foto').slick({
  dots: true,
  autoplay:true,
  infinite: true,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  accessibility: true,
  arrows: true,
  prevArrow: '<i class="fa fa-2x fa-chevron-circle-left custom-prev"></i>',
  nextArrow: '<i class="fa fa-2x fa-chevron-circle-right custom-next"></i>',
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
$('.carousel-galeri-video').slick({
  dots: true,
  autoplay:true,
  infinite: true,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 4,
  accessibility: true,
  arrows: true,
  prevArrow: '<i class="fa fa-2x fa-chevron-circle-left custom-prev"></i>',
  nextArrow: '<i class="fa fa-2x fa-chevron-circle-right custom-next"></i>',
  responsive: [
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 3,
        infinite: true,
        dots: true
      }
    },
    {
      breakpoint: 600,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 2
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
});
    
</script>
<script src="<?php echo site_url();?>/assets/js/owl.carousel.min.js"></script>
<script type="text/javascript">
$('.owl-carousel').owlCarousel({
    margin:10,
    autoWidth:true,
    navigation:true,
    items:5,
    loop:true,
    dots:false,
    autoplay:true,
    /*autoplayHoverPause:true,*/
    responsiveClass:false,
    responsive:false,
    navText : ["",""],
    rewindNav : true
})

<!--
var months = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
var myDays = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
var date = new Date();
var day = date.getDate();
var month = date.getMonth();
var thisDay = date.getDay(),
    thisDay = myDays[thisDay];
var yy = date.getYear();
var year = (yy < 1000) ? yy + 1900 : yy;
//-->

<!--
function checkTime(i) {
    if (i<10) {
        i="0" + i;
    }
    return i;
}

//-->
</script>
</body>
</html>