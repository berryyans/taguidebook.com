<?php

/**
 * Created by Yanno Dwi Ananda
 * Date: 1/19/2018
 * Time: 12:28 PM
 */
class DataAccount extends MY_Model {

}